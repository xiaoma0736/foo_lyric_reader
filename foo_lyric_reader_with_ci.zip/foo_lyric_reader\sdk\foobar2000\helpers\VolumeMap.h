#pragma once

namespace VolumeMap {
	double SliderToDB(double slider /*0..1 range*/);
	double DBToSlider(double volumeDB);
}
