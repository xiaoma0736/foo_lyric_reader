#include "stdafx.h"
#include "lyric_callback.h"
#include "config.h"

LyricCallback::LyricCallback(ISpVoice *pVoice) : m_refCount(1), m_voice(pVoice)
{
	if (m_voice)
	{
		m_voice->AddRef();
	}
}

LyricCallback::~LyricCallback()
{
	if (m_voice)
	{
		m_voice->Release();
	}
}

STDMETHODIMP LyricCallback::QueryInterface(REFIID riid, void **ppvObject)
{
	if (!ppvObject) return E_POINTER;

	if (riid == IID_IUnknown || riid == IID_IDispatch)
	{
		*ppvObject = static_cast<IDispatch*>(this);
		AddRef();
		return S_OK;
	}

	*ppvObject = NULL;
	return E_NOINTERFACE;
}

STDMETHODIMP_(ULONG) LyricCallback::AddRef()
{
	return InterlockedIncrement(&m_refCount);
}

STDMETHODIMP_(ULONG) LyricCallback::Release()
{
	ULONG refCount = InterlockedDecrement(&m_refCount);
	if (refCount == 0)
	{
		delete this;
	}
	return refCount;
}

STDMETHODIMP LyricCallback::GetTypeInfoCount(UINT *pctinfo)
{
	return E_NOTIMPL;
}

STDMETHODIMP LyricCallback::GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo)
{
	return E_NOTIMPL;
}

STDMETHODIMP LyricCallback::GetIDsOfNames(REFIID riid, LPOLESTR *rgszNames, UINT cNames, LCID lcid, DISPID *rgDispId)
{
	return E_NOTIMPL;
}

STDMETHODIMP LyricCallback::Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *pDispParams, VARIANT *pVarResult, EXCEPINFO *pExcepInfo, UINT *puArgErr)
{
	if (cfg_enabled && m_voice && wFlags & DISPATCH_METHOD)
	{
		if (pDispParams && pDispParams->cArgs > 0 && pDispParams->rgv[0].vt == VT_BSTR)
		{
			const BSTR bstrLyric = pDispParams->rgv[0].bstrVal;
			
			if (wcslen(bstrLyric) > 0) {
				m_voice->Speak(bstrLyric, SPF_ASYNC | SPF_PURGEBEFORESPEAK, NULL);
			}
		}
	}
	return S_OK;
}
