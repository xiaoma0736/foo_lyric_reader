#include "stdafx.h"
#include <objbase.h>
#include <sapi.h>
#include "lyric_callback.h"

class myinitquit : public initquit {
	IDispatch* m_eslyric;
	LyricCallback* m_callback;
	ISpVoice* m_voice;

public:
	myinitquit() : m_eslyric(nullptr), m_callback(nullptr), m_voice(nullptr) {}

	void on_init() {
		console::print("Lyric Reader: on_init()");
		HRESULT hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
		if (SUCCEEDED(hr)) {
			console::print("Lyric Reader: COM/SAPI Initialized successfully.");

			hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void**)&m_voice);
			if (SUCCEEDED(hr)) {
				console::print("Lyric Reader: Successfully created SAPI voice instance.");
			} else {
				m_voice = nullptr;
				console::formatter() << "Lyric Reader: Failed to create SAPI voice, HRESULT: " << hr;
			}

			CLSID clsid;
			hr = CLSIDFromProgID(L"eslyric", &clsid);
			if (SUCCEEDED(hr)) {
				hr = CoCreateInstance(clsid, NULL, CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&m_eslyric);
				if (SUCCEEDED(hr)) {
					console::print("Lyric Reader: Successfully created ESLyric COM object instance.");
					
					m_callback = new LyricCallback(m_voice); // Pass voice pointer to callback

					DISPID dispId;
					LPOLESTR callbackName = (LPOLESTR)L"SetPlayingLyricChangedCallback";
					hr = m_eslyric->GetIDsOfNames(IID_NULL, &callbackName, 1, LOCALE_USER_DEFAULT, &dispId);
					if (SUCCEEDED(hr)) {
						DISPPARAMS params;
						memset(&params, 0, sizeof(params));
						params.cArgs = 1;
						VARIANTARG* var = new VARIANTARG[1];
						var[0].vt = VT_DISPATCH;
						var[0].pdispVal = m_callback;
						params.rgv = var;

						hr = m_eslyric->Invoke(dispId, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &params, NULL, NULL, NULL);
						delete[] var;
						if (SUCCEEDED(hr)) {
							console::print("Lyric Reader: Successfully registered lyric change callback.");
						} else {
							console::formatter() << "Lyric Reader: Failed to invoke SetPlayingLyricChangedCallback, HRESULT: " << hr;
						}
					} else {
						console::formatter() << "Lyric Reader: Failed to get DISPID for SetPlayingLyricChangedCallback, HRESULT: " << hr;
					}

				} else {
					m_eslyric = nullptr;
					console::formatter() << "Lyric Reader: CoCreateInstance for ESLyric failed, HRESULT: " << hr;
				}
			} else {
				console::formatter() << "Lyric Reader: CLSIDFromProgID for ESLyric failed, HRESULT: " << hr;
			}

		} else {
			console::formatter() << "Lyric Reader: CoInitializeEx failed, HRESULT: " << hr;
		}
	}
	void on_quit() {
		console::print("Lyric Reader: on_quit()");
		if (m_callback != nullptr) {
			m_callback->Release();
			m_callback = nullptr;
			console::print("Lyric Reader: Released LyricCallback object.");
		}
		if (m_eslyric != nullptr) {
			m_eslyric->Release();
			m_eslyric = nullptr;
			console::print("Lyric Reader: Released ESLyric COM object.");
		}
		if (m_voice != nullptr) {
			m_voice->Release();
			m_voice = nullptr;
			console::print("Lyric Reader: Released SAPI voice.");
		}
		CoUninitialize();
		console::print("Lyric Reader: COM/SAPI Uninitialized.");
	}
};

static initquit_factory_t<myinitquit> g_myinitquit_factory;
