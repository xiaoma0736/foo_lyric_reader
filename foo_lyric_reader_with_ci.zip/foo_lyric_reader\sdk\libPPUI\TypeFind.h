#pragma once

class TypeFind {
public:
	static LRESULT Handler(NMHDR* hdr, int subItemFrom = 0, int subItemCnt = 1);
};
