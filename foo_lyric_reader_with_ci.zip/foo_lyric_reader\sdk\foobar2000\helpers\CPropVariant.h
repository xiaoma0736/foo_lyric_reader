#pragma once

#include <libPPUI/CPropVariant.h>