#pragma once

#include "foobar2000/SDK/cfg_var.h"

// GUID for our setting
static const GUID guid_cfg_enabled = { 0x9a5578d8, 0x22a2, 0x47d3, { 0xb8, 0x24, 0x6b, 0xe1, 0x36, 0x32, 0x7a, 0x34 } };

// Declaration of our setting variable
extern cfg_bool cfg_enabled;
