#include "stdafx.h"
#include "resource.h"
#include "config.h"
#include <helpers/atl-misc.h>

// Our setting variable, declared in config.h
cfg_bool cfg_enabled(guid_cfg_enabled, true);

// This GUID identifies our preferences page.
static const GUID guid_preferences_page = { 0x7702c93e, 0x24dc, 0x48ed, { 0x8d, 0xb1, 0x3f, 0x27, 0xb3, 0x8c, 0x7c, 0xc9 } };


class CMyPreferences : public CDialogImpl<CMyPreferences>, public preferences_page_instance {
public:
	CMyPreferences(preferences_page_callback::ptr callback) : m_callback(callback) {}

	// WTL dialog resource ID
	enum {IDD = IDD_MYPREFERENCES};

	// preferences_page_instance methods
	t_uint32 get_state();
	void apply();
	void reset();

	// WTL message map
	BEGIN_MSG_MAP_EX(CMyPreferences)
		MSG_WM_INITDIALOG(OnInitDialog)
		COMMAND_HANDLER_EX(IDC_ENABLE_CHECKBOX, BN_CLICKED, OnCheckboxChange)
	END_MSG_MAP()

private:
	BOOL OnInitDialog(CWindow, LPARAM);
	void OnCheckboxChange(UINT, int, CWindow);
	bool HasChanged();
	void OnChanged();

	const preferences_page_callback::ptr m_callback;
};

BOOL CMyPreferences::OnInitDialog(CWindow, LPARAM) {
	// Set the checkbox state from our cfg_bool variable
	CheckDlgButton(IDC_ENABLE_CHECKBOX, cfg_enabled ? BST_CHECKED : BST_UNCHECKED);
	return FALSE;
}

void CMyPreferences::OnCheckboxChange(UINT, int, CWindow) {
	OnChanged();
}

t_uint32 CMyPreferences::get_state() {
	t_uint32 state = preferences_state::resettable;
	if (HasChanged()) state |= preferences_state::changed;
	return state;
}

void CMyPreferences::reset() {
	// Reset to default value (true)
	CheckDlgButton(IDC_ENABLE_CHECKBOX, true ? BST_CHECKED : BST_UNCHECKED);
	OnChanged();
}

void CMyPreferences::apply() {
	// Get the checkbox state and save it to our cfg_bool variable
	cfg_enabled = IsDlgButtonChecked(IDC_ENABLE_CHECKBOX) == BST_CHECKED;
	OnChanged();
}

bool CMyPreferences::HasChanged() {
	// Return whether our dialog content is different from the current configuration
	return (IsDlgButtonChecked(IDC_ENABLE_CHECKBOX) == BST_CHECKED) != cfg_enabled;
}

void CMyPreferences::OnChanged() {
	// Tell the host that our state has changed to enable/disable the apply button
	m_callback->on_state_changed();
}


class preferences_page_myimpl : public preferences_page_impl<CMyPreferences> {
public:
	const char * get_name() { return "Lyric Reader"; }
	GUID get_guid() { return guid_preferences_page; }
	GUID get_parent_guid() { return guid_tools; }
};

static preferences_page_factory_t<preferences_page_myimpl> g_preferences_page_myimpl_factory;

